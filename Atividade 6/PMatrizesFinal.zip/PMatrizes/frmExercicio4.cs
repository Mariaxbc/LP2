﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] tamanho = new int[10];
            string[] nomes = new string[10];

            string aux = "";

            lstbxNomes.Items.Clear();

            for (int i = 0; i < nomes.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o nome completo da pessoa {i + 1}", "Entrada de Dados");

                if (aux.Trim() == "")
                {
                    MessageBox.Show("Insira um nome válido!");
                    i--;
                }

                else
                {
                    nomes[i] = aux;

                    string nomeJunto = aux.Replace(" ", ""); //substitui o primeiro pelo segundo, ou seja, vai tirar o espaço em branco :D

                    tamanho[i] = nomeJunto.Length;

                }
            }


            for (int i = 0; i < nomes.Length; i++)
            {
                lstbxNomes.Items.Add($"o Nome: {nomes[i]} tem {tamanho[i]} caracteres");
            }
        }
    }
}

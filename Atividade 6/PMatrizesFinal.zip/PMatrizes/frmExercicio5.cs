﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int acertos = 0;
            int N = 2;

            string[,] respostas = new string[N, 10];

            string[] gabarito =
            {
                "A","B","C","E","D",
                "E","D","C","A","B"
            };

            string aux = "";

            lstboxCorrecao.Items.Clear();
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    aux = Interaction.InputBox($"Aluno {i + 1} - Questão {j + 1}", "Digite A, B, C, D ou E").ToUpper();

                    if (aux != "A" && aux != "B" && aux != "C" && aux != "D" && aux != "E")
                    {
                        MessageBox.Show("Digite apenas A, B, C, D ou E");
                        j--;
                    }
                    else
                    {
                        respostas[i, j] = aux;
                    }
                }
            }

            for (int i = 0; i < N; i++)
            {
                acertos = 0; //zerar os acertos pra cada aluno;
                for (int j = 0; j < 10; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                    {
                        lstboxCorrecao.Items.Add(
                            $"O aluno: {i + 1} acertou questão: {j + 1} " + $"era {gabarito[j]} escolheu {respostas[i, j]}");

                        acertos++;
                    }
                    else
                    {
                        lstboxCorrecao.Items.Add(
                            $"O aluno: {i + 1} errou questão: {j + 1} " + $"era {gabarito[j]} escolheu {respostas[i, j]}");
                    }
                }
                lstboxCorrecao.Items.Add($"Total de Acertos do aluno: {acertos}");

                lstboxCorrecao.Items.Add("");
            }
        }
    }
}
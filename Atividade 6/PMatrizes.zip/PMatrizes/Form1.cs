﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";
            for(int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o número {i+1}", "Entrada de dados");

                if(!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido. Digite um número inteiro.");
                    i--; // Decrementa o índice para tentar novamente
                }
            }

            Array.Reverse(vetor);
            aux = " ";
            foreach(int x in vetor)
                {
                aux += x + "\n";
                }
            MessageBox.Show(aux);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();

            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Beatriz");
            alunos.Add("Camilia");
            alunos.Add("João");
            alunos.Add("Joana");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

            string resultado = string.Join("\n", alunos.Cast<string>());

            MessageBox.Show(resultado);


        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            float[,] notaAlunos = new float[20, 3];
            string aux = "";

            for (int i = 0; i < notaAlunos.Length; i++)
            {
                for (int j = 0; j < notaAlunos.Length; j++)
                {

            //fazer TryParse para validar a entrada de dados
                    aux = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (!float.TryParse(aux, out notaAlunos[i, j]))
                    {
                        MessageBox.Show("Valor inválido. Digite um número decimal.");
                        j--; // Decrementa o índice para tentar novamente
                    }
                }
            }


        }
    }
}

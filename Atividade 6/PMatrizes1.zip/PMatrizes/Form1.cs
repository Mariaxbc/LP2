﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";
            for(int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o número {i+1}", "Entrada de dados");

                if(!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido. Digite um número inteiro.");
                    i--; // Decrementa o índice para tentar novamente
                }
            }

            Array.Reverse(vetor);
            aux = " ";
            foreach(int x in vetor)
                {
                aux += x + "\n";
                }
            MessageBox.Show(aux);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();

            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Beatriz");
            alunos.Add("Camilia");
            alunos.Add("João");
            alunos.Add("Joana");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

            string resultado = string.Join("\n", alunos.Cast<string>());

            MessageBox.Show(resultado);


        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notaAlunos = new double[20, 3];
            string aux = "";
            double media = 0;
            string mediaAluno = "";

            for (int i = 0; i < notaAlunos.GetLength(0); i++)
            {

                media = 0;

                for (int j = 0; j < notaAlunos.GetLength(1); j++)
                {

            //fazer TryParse para validar a entrada de dados
                    aux = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");

                    if (!double.TryParse(aux, out notaAlunos[i, j]) || notaAlunos[i, j] < 0 || notaAlunos[i, j] > 10)
                    {
                        MessageBox.Show("Valor inválido. Digite um número decimal.");
                        j--; // Decrementa o índice para tentar novamente
                    }

                    else
                    {
                        media += notaAlunos[i, j];
                    }
                }

                mediaAluno += $"Aluno {i + 1}: média {media / 3:F2}\n";
            }

            MessageBox.Show(mediaAluno);



        }

        private void btnEx4_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int qtdeEspacos;
            qtdeEspacos = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    qtdeEspacos++;
                }
            }

            txtResultado.Text = $"A quantidade de espaços na frase é {qtdeEspacos.ToString()}";
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int qtdeR;
            qtdeR = 0;

            for (int i = 0; i < rchtxtFrase.TextLength; i++)
            {
                {
                    if (char.ToUpper(rchtxtFrase.Text[i]) == 'R')
                        qtdeR++;
                }
            }

            txtResultado.Text = $"A quantidade de R na frase é {qtdeR.ToString()}";

        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int qtdePar;
            qtdePar = 0;

            for (int i = 0; i < rchtxtFrase.TextLength - 1; i++)
            {
                if(rchtxtFrase.Text[i] == rchtxtFrase.Text[i + 1])
                    qtdePar++;
            }

            txtResultado.Text = $"A quantidade de pares na frase é {qtdePar.ToString()}";

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string frase, textoSemEspaco = "", textoInvertido = "";

            frase = txtFrase.Text.ToUpper(); 

            for (int i = 0; i < txtFrase.Text.Length; i++)
            {
                if (frase[i] != ' ') 
                {
                    textoSemEspaco += frase[i]; 
                }
            }

            for (int i = textoSemEspaco.Length - 1; i >= 0; i--)  {
                textoInvertido += textoSemEspaco[i];
            }

            //Condição que informa se é ou não palíndromo -------------------------------------------------

            if (textoSemEspaco == textoInvertido) //como n da pra usar txtFrase vou usar o textoSemEspaco
            {
                MessageBox.Show("A palavra/frase inserida é um palíndromo! :D");
            }

            else
            {
                MessageBox.Show("A palavra/frase inserida não é um palíndromo! D:");
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtFrase.Clear();
            txtFrase.Focus();
        }
    }
}

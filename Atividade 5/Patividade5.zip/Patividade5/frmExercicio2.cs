﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio2 : Form
    {
        int Num;
        int H;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double H = 0;

            Num = Convert.ToInt32(txtResultado.Text); //Usar pra separar str de int
            {
                for (int i = 1; i <= Num; i++) 
                {
                    H = H + (1.0 / i);
                }
                MessageBox.Show("H vale " + H.ToString("f2")); //H pra str e limitar pra duas casas decimais!
            }
        }

        private void txtResultado_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtResultado.Text, out int numero) || numero == 0)
            {
                MessageBox.Show("Digite um número inteiro maior que 0!");
            }
        }
    }
}

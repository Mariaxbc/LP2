﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio4 : Form
    {
        //Declaração e configuração de variáveis --------------------------------------------------------------
        string nome;
        int matricula, producao; //Vou criar a variável por precaução, pq aparentemente n usa no código :D
        double gratificacao, salario, salarioBruto;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void txtMatricula_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtMatricula.Text, out matricula))
            {
                MessageBox.Show("Digite um valor válido, por favor!");
                return;
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Digite um valor válido, por favor!");
                return;
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtSalario.Text, out salario))
            {
                MessageBox.Show("Digite um valor válido, por favor!");
                return;
            }
        }

        private void btnSalario_Click(object sender, EventArgs e)
        {

            
            int B = 0;
            int C = 0;
            int D = 0;

            nome = txtNome.Text;
            producao = Convert.ToInt32(txtProducao.Text);
            matricula = Convert.ToInt32(txtMatricula.Text);
            gratificacao = Convert.ToDouble(txtGratificacao.Text);
            salario = Convert.ToDouble(txtSalario.Text);

            //Regras pro cálculo ---------------------------------------------------------------------------------

            if (producao >= 100)
            {
                B = 1;
            }

            else
            {
                B = 0;
            }

            if (producao >= 120)
            {
                C = 1;
            }

            else
            {
                C = 0;
            }

            if (producao >= 150)
            {
                D = 1;
            }

            else
            {
                D = 0;
            }

            // conta do salário bruto!---------------------------------------------------------------

            salarioBruto = salario + (salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao);

            // limitação de salário de acordo com produção e exibição do resultado. --------------------------------------------

            if (salarioBruto > 7000)
            {
                if (producao >= 150 && gratificacao > 0)
                {
                    MessageBox.Show("O(a) funcionário(a): " + nome + "\n Da Matrícula: " + matricula + "\n Terá " + salarioBruto.ToString("f2") + " como valor de salário bruto!");
                }

                else
                {
                    MessageBox.Show("O(a) funcionário(a): " + nome + "\n Da Matrícula: " + matricula + "\n Terá 7000 como valor de salário bruto!");
                }
            }

            else
            {
                MessageBox.Show("O(a) funcionário(a): " + nome + "\n Da Matrícula: " + matricula + "\n Terá " + salarioBruto.ToString("f2") + " como valor de salário bruto!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtGratificacao.Text = "";
            txtMatricula.Text = "";
            txtNome.Text = "";
            txtProducao.Text = "";
            txtSalario.Text = "";
            txtNome.Focus();
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if(!int.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Digite um número válido, por favor!");
                return;
            }
        }
    }
}

﻿namespace PtesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCortaNum = new System.Windows.Forms.Button();
            this.btnLocaliza = new System.Windows.Forms.Button();
            this.btnContaLetra = new System.Windows.Forms.Button();
            this.rcRtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnCortaNum
            // 
            this.btnCortaNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCortaNum.Location = new System.Drawing.Point(147, 491);
            this.btnCortaNum.Name = "btnCortaNum";
            this.btnCortaNum.Size = new System.Drawing.Size(248, 141);
            this.btnCortaNum.TabIndex = 0;
            this.btnCortaNum.Text = "Corta Números";
            this.btnCortaNum.UseVisualStyleBackColor = true;
            this.btnCortaNum.Click += new System.EventHandler(this.btnCortaNum_Click);
            // 
            // btnLocaliza
            // 
            this.btnLocaliza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocaliza.Location = new System.Drawing.Point(526, 491);
            this.btnLocaliza.Name = "btnLocaliza";
            this.btnLocaliza.Size = new System.Drawing.Size(248, 141);
            this.btnLocaliza.TabIndex = 1;
            this.btnLocaliza.Text = "Posição 1° Caracter Branco";
            this.btnLocaliza.UseVisualStyleBackColor = true;
            this.btnLocaliza.Click += new System.EventHandler(this.btnLocaliza_Click);
            // 
            // btnContaLetra
            // 
            this.btnContaLetra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaLetra.Location = new System.Drawing.Point(883, 491);
            this.btnContaLetra.Name = "btnContaLetra";
            this.btnContaLetra.Size = new System.Drawing.Size(248, 141);
            this.btnContaLetra.TabIndex = 2;
            this.btnContaLetra.Text = "Conta Letras";
            this.btnContaLetra.UseVisualStyleBackColor = true;
            this.btnContaLetra.Click += new System.EventHandler(this.btnContaLetra_Click);
            // 
            // rcRtxtFrase
            // 
            this.rcRtxtFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcRtxtFrase.Location = new System.Drawing.Point(147, 40);
            this.rcRtxtFrase.Name = "rcRtxtFrase";
            this.rcRtxtFrase.Size = new System.Drawing.Size(992, 389);
            this.rcRtxtFrase.TabIndex = 3;
            this.rcRtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1260, 709);
            this.Controls.Add(this.rcRtxtFrase);
            this.Controls.Add(this.btnContaLetra);
            this.Controls.Add(this.btnLocaliza);
            this.Controls.Add(this.btnCortaNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCortaNum;
        private System.Windows.Forms.Button btnLocaliza;
        private System.Windows.Forms.Button btnContaLetra;
        private System.Windows.Forms.RichTextBox rcRtxtFrase;
    }
}
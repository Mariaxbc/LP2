﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNum1.Text, out int Num1) || !int.TryParse(txtNum2.Text, out int Num2))
            { 
                return; 
            }

            Random Obj = new Random();
            int Sorteio = Obj.Next(Num1, Num2);
            MessageBox.Show(Sorteio.ToString());
        }
    }
}

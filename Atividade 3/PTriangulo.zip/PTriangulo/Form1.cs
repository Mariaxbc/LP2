﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB) || ladoB <= 0)

            {
                MessageBox.Show("Valor inválido para o lado B. Por favor, insira um número válido.");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC) || ladoC <= 0)
            {
                MessageBox.Show("Valor inválido para o lado C. Por favor, insira um número válido.");
                txtLadoC.Focus();
            }
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if ((ladoA<(ladoB+ladoC)) &&
                (ladoA>(Math.Abs(ladoB-ladoC))) &&
                (ladoB<(ladoA+ladoC)) &&
                (ladoB>(Math.Abs(ladoA-ladoC))) &&
                (ladoC<(ladoA+ladoB)) &&
                (ladoC>(Math.Abs(ladoA-ladoB))))

            {
                if ((ladoA == ladoB) && (ladoB == ladoC) && (ladoA == ladoC))
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if ((ladoA == ladoB) || (ladoB == ladoC) || (ladoA == ladoC))
                {
                    MessageBox.Show("Triângulo Isósceles");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Os lados informados não formam um triângulo.");

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA) || ladoA <= 0)

            {
                MessageBox.Show("Valor inválido para o lado A. Por favor, insira um número válido.");
                txtLadoA.Focus();
            }
        }
    }
}

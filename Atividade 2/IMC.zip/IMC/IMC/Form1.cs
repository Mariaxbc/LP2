﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
            double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskdboxPeso_Validated(object sender, EventArgs e)
        {
    
            {
                if (!double.TryParse(mskdboxPeso.Text, out peso) || (peso <= 0))
                {
                    MessageBox.Show("Valor de peso inválido. Por favor, insira um número válido.");
                    mskdboxPeso.Focus();
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskdboxAltura.Clear();
            mskdboxPeso.Clear();
            mskdboxIMC.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskdboxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskdboxAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Valor de altura inválido. Por favor, insira um número válido.");
                mskdboxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));

            imc = Math.Round(imc, 1); //arredondei
            mskdboxIMC.Text = imc.ToString("");

            if (imc < 18.5)
                MessageBox.Show("Abaixo do peso");
            else if (imc <= 24.9)
                MessageBox.Show("Peso normal");
            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso");
            else if (imc <= 39.9)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade grave");
        }
    }
}
